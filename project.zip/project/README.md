SholatYuk

This is a flask-based web app to show the muslim prayer times from a particular location (adress/city) and particular date/month.

User can enter the location they wish to find out the prayer times, and the calculation method. There are two options, getting the monthly schedule or daily schedule.

In monthly schedule, user can get whichever month he wish. And a monthly timetable (the number of rows depend on the number of days within that particular month) will show up.

If user choose to get daily, it will show the schedule for that particular day (the day on which the user accesses) with analog clocks as time indicator for each prayer times, as well as a running manual clock that shows the actual time.

Apart from praying stuff, there is  also a qibla direction finder, which will show the heading direction (relative to the north) one should pray towards just by allowing browser to get the location.